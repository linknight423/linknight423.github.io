import cv2
from enlighten_inference import EnlightenOnnxModel, get_relative_path


def test_smoke():
    img = cv2.imread(get_relative_path(__file__, r'C:\Users\10574\Desktop\深度学习及其应用\期末大作业\EnlightenGAN-inference-main\EnlightenGAN-inference-main\tests\chicken.jpeg'))
    print(img)
    # model = EnlightenOnnxModel()
    # processed = model.predict(img)
    #
    # assert img.shape == processed.shape
    # assert img.mean() < processed.mean()

test_smoke()